package ch04;

public class Constructor {
	
	public Constructor() {
		int a =  1;
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		new Constructor();
	}
}
