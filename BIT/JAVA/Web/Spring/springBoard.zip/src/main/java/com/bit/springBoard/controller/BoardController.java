package com.bit.springBoard.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bit.springBoard.dao.IDao;

@Controller
public class BoardController {
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping(value="writeView")
	public String writeView() {return "writeView";}
	
	@RequestMapping(value="list")
	public String list(Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		model.addAttribute("list", dao.listBoard());  //arraylist<boarddto>를 list변수명으로 model에 저장
		return "list";  //list.jsp호출
	}
	
	@RequestMapping(value="contentView")
	public String contentView(int id, Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.upHitBoard(id); //조회수를 먼저 증가
		model.addAttribute("contentView", dao.viewBoard(id));
		return "contentView";
	}
	
	@RequestMapping(value="write")
	//writeView.jsp에서 name값이 매개변수와 동일하면 자동적으로 주입
	public String write(String name, String title, String content) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.writeBoard(name, title, content);
		return "redirect:list";
	}
	
	@RequestMapping(value="modify")
	public String modify(String name, String title, String content, int id) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.modifyBoard(name, title, content,id);
		return "redirect:list";
	}
	
	@RequestMapping(value="delete")
	public String delete(int id) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.deleteBoard(id);
		return "redirect:list";
	}
	
}
