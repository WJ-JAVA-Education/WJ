package funding;

import java.io.IOException;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SendPwd")
public class SendPwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String toEmail = request.getParameter("email");
		String content = ("�̸��� " + request.getParameter("email") + "�� ��й�ȣ�� : " + request.getParameter("pwd") + "�Դϴ�");
		String title = ("I.Funding.U ����Ʈ�� ��й�ȣ Ȯ�� �����Դϴ�.");
		
		Properties p = new Properties();
	    p.put("mail.smtp.user", "gisikcho2@naver.com"); //���� ������
	    p.put("mail.smtp.host", "smtp.naver.com");
	    p.put("mail.smtp.port", "465");
	    p.put("mail.smtp.starttls.enable", "true");
	    p.put("mail.smtp.auth", "true");

	    p.put("mail.smtp.debug", "true");
	    p.put("mail.smtp.socketFactory.port", "465");
	    p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	    p.put("mail.smtp.socketFactory.fallback", "false");

	    try {
	      Authenticator auth = new SMTPAuthenticator();
	      Session session = Session.getInstance(p, auth);
	      session.setDebug(true); 

	      MimeMessage msg = new MimeMessage(session);
	      String message = content;
	      msg.setSubject(title);
	      
	      Address fromAddr = new InternetAddress("gisikcho2@naver.com"); 
	      msg.setFrom(fromAddr);
	      
	      Address toAddr = new InternetAddress(toEmail); 
	      msg.addRecipient(Message.RecipientType.TO, toAddr);
	      msg.setContent(message, "text/plain;charset=KSC5601");
	      
	      Transport.send(msg);
	      
	    } catch (Exception e) { 
	      e.printStackTrace();
	    }
	  }

	  private static class SMTPAuthenticator extends Authenticator {
	    public PasswordAuthentication getPasswordAuthentication() {
	      //������ ���̵� , ��й�ȣ
	      return new PasswordAuthentication("gisikcho2@naver.com", "1234cho@");
	    }
	  }
	  
		
		
	}


