package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import funding.DBConnectionMgr;
import funding.ProInsBean;
import funding.MemberBean;

public class AdminMgr {
	
	private DBConnectionMgr pool;
	
	public AdminMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//������Ʈ ����Ʈ �ҷ�����
	public Vector<ProInsBean> getProductList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT Pro_No, email, Pro_name, Pro_goal, Pro_check FROM project WHERE Pro_check != 1 AND Pro_check != 2 ORDER BY Pro_No DESC";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt("Pro_No"));
				bean.setEmail(rs.getString("email"));
				bean.setPro_name(rs.getString("Pro_name"));
				bean.setPro_goal(rs.getInt("Pro_goal"));
				bean.setPro_check(rs.getInt("Pro_check"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//������Ʈ ���� �� Pro_check�� 1�� ����.
	public boolean updateProject(int Pro_No, int Pro_check) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "update project set Pro_check = ? WHERE Pro_No = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_check);
			pstmt.setInt(2, Pro_No);
			if(pstmt.executeUpdate()==1)
				flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//������Ʈ ����� �� Pro_check�� 2�� ����.
	public boolean RepeatProject(int Pro_No, int Pro_check) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "update project set Pro_check = ? WHERE Pro_No = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_check);
			pstmt.setInt(2, Pro_No);
			if(pstmt.executeUpdate()==1)
				flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
}
