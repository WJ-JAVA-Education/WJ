package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class PromemberMgr {

private DBConnectionMgr pool;
	
	public PromemberMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//shipment DB
	public Vector<Promemberbean> getPromember() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<Promemberbean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM shipment";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Promemberbean bean = new Promemberbean();
				bean.setEmail(rs.getString("email")); //�ݵ� �� ����� �̸���
				bean.setCardnum(rs.getString("cardnum")); //ī�� ��ȣ
				bean.setPhone(rs.getString("phone")); // ����� ����� ��ȣ
				bean.setPro_No(rs.getInt("Pro_No")); // �ݵ��� ������Ʈ �ѹ�
				bean.setName(rs.getString("name")); //��۹��� ����� �̸�
				bean.setPostnum(rs.getInt("postnum")); //��۹��� ������ȣ
				bean.setAddress1(rs.getString("address1")); //��۹��� ���θ�
				bean.setAddress2(rs.getString("address2")); //��۹��� �� �ּ�
				bean.setRew_opt(rs.getString("rew_opt")); //������ �ɼ�
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//shipment email
	public Vector<String> getPromemberemail() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<String> elist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT email FROM shipment";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				elist.addElement(rs.getString("email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return elist;
	}
	
	//shipment Pro_No
		public Vector<Integer> getPromembernum() {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<Integer> pnlist  = new Vector<>();
			try {
				con = pool.getConnection();
				sql = "SELECT Pro_No FROM shipment";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					pnlist.addElement(rs.getInt("Pro_No"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return pnlist;
		}
}
