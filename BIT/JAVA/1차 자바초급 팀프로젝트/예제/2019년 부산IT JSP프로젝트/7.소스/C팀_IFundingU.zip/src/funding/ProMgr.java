package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class ProMgr {
	
	private DBConnectionMgr pool;
	
	public ProMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	public Vector<ProInsBean> getAllProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate > now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate > now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate > now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate > now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_check=1 and pro_findate > now() and pro_name like ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getLongProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=1 and pro_check=1 and pro_findate > now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=1 and pro_check=1 and pro_findate > now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=1 and pro_check=1 and pro_findate > now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=1 and pro_check=1 and pro_findate > now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_cat=1 and pro_check=1 and pro_findate > now() and pro_name like ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getShortProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=2 and pro_check=1 and pro_findate > now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=2 and pro_check=1 and pro_findate > now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=2 and pro_check=1 and pro_findate > now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=2 and pro_check=1 and pro_findate > now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_cat=2 and pro_check=1 and pro_findate > now() and pro_name like ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getAniProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=3 and pro_check=1 and pro_findate > now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=3 and pro_check=1 and pro_findate > now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=3 and pro_check=1 and pro_findate > now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=3 and pro_check=1 and pro_findate > now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_cat=3 and pro_check=1 and pro_findate > now() and pro_name like  ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getDocuProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=4 and pro_check=1 and pro_findate > now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=4 and pro_check=1 and pro_findate > now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=4 and pro_check=1 and pro_findate > now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_cat=4 and pro_check=1 and pro_findate > now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_cat=4 and pro_check=1 and pro_findate > now() and pro_name like ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getCompleteProList(int line, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			if(keyWord.equals("null")||keyWord.equals("")) {
			if(line == 1) {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate <= now() ORDER BY pro_patron desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			}else if(line == 2){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate <= now() ORDER BY pro_cash desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 3){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate <= now() ORDER BY pro_findate"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}else if(line == 0){
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project WHERE pro_check=1 and pro_findate <= now() ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);	
			}
			}else {
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_check=1 and pro_findate <= now() and pro_name like ? order by pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyWord+"%");	
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getMyProList(String email) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where Pro_check = 1 and email=? ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	// �� ������ ������Ʈ
	public Vector<ProInsBean> getMyPatronList(String email) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT project.pro_No, project.pro_name, project.pro_goal, project.pro_findate, project.pro_cash, project.pro_img, project.email, shipment.email FROM project LEFT join shipment ON (project.pro_No = shipment.Pro_No) WHERE shipment.email = ? ORDER BY pro_No desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<ProInsBean> getMyConsiderProList(String email) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProInsBean> vlist  = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "SELECT pro_No, pro_name, pro_goal, pro_findate, pro_cash, pro_img, email FROM project where pro_check = 2 and email=? ORDER BY pro_No desc"; //order by no desc�� order by 1 desc�� �ص� ����. select from ���� ����(1~5) ��ȣ
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProInsBean bean = new ProInsBean();
				bean.setPro_No(rs.getInt(1));
				bean.setPro_name(rs.getString(2));
				bean.setPro_goal(rs.getInt(3));
				bean.setPro_findate(rs.getString(4));
				bean.setPro_cash(rs.getInt(5));
				bean.setPro_img(rs.getString(6));
				bean.setEmail(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}
