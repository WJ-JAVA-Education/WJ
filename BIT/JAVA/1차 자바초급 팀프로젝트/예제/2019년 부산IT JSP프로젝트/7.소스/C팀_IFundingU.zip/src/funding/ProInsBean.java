package funding;

public class ProInsBean {
    private int Pro_No; 
    private String Pro_name; 
    private int Pro_goal; 
    private String Pro_img; 
    private int Pro_cat; 
    private String Pro_Adrs; 
    private String Pro_findate; 
    private int Pro_bank; 
    private String Pro_acnt; 
    private String Pro_refund; 
    private String Pro_story; 
    private int Pro_check; 
    private int Pro_cash;
    private int Pro_patron;
    private String email;
    private int line;
    
	public int getLine() {
		return line;
	}
	public void setLine(int line) {
		this.line = line;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPro_No() {
		return Pro_No;
	}
	public void setPro_No(int pro_No) {
		Pro_No = pro_No;
	}
	public String getPro_name() {
		return Pro_name;
	}
	public void setPro_name(String pro_name) {
		Pro_name = pro_name;
	}
	public int getPro_goal() {
		return Pro_goal;
	}
	public void setPro_goal(int pro_goal) {
		Pro_goal = pro_goal;
	}
	public String getPro_img() {
		return Pro_img;
	}
	public void setPro_img(String pro_img) {
		Pro_img = pro_img;
	}
	public int getPro_cat() {
		return Pro_cat;
	}
	public void setPro_cat(int pro_cat) {
		Pro_cat = pro_cat;
	}
	public String getPro_Adrs() {
		return Pro_Adrs;
	}
	public void setPro_Adrs(String pro_Adrs) {
		Pro_Adrs = pro_Adrs;
	}
	public String getPro_findate() {
		return Pro_findate;
	}
	public void setPro_findate(String pro_findate) {
		Pro_findate = pro_findate;
	}
	public int getPro_bank() {
		return Pro_bank;
	}
	public void setPro_bank(int pro_bank) {
		Pro_bank = pro_bank;
	}
	public String getPro_acnt() {
		return Pro_acnt;
	}
	public void setPro_acnt(String pro_acnt) {
		Pro_acnt = pro_acnt;
	}
	public String getPro_refund() {
		return Pro_refund;
	}
	public void setPro_refund(String pro_refund) {
		Pro_refund = pro_refund;
	}
	public String getPro_story() {
		return Pro_story;
	}
	public void setPro_story(String pro_story) {
		Pro_story = pro_story;
	}
	public int getPro_check() {
		return Pro_check;
	}
	public void setPro_check(int pro_check) {
		Pro_check = pro_check;
	}
	public int getPro_cash() {
		return Pro_cash;
	}
	public void setPro_cash(int pro_cash) {
		Pro_cash = pro_cash;
	} 
	public int getPro_patron() {
		return Pro_patron;
	}
	public void setPro_patron(int pro_patron) {
		Pro_patron = pro_patron;
	}
	
}
