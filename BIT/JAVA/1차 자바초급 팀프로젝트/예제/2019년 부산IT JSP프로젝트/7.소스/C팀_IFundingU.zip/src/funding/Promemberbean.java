package funding;

public class Promemberbean {

		private int orderno;
		private String email;
		private String cardnum;
		private String phone;
		private int pro_No;
		private String name;
		private int postnum;
		private String address1;
		private String address2;
		private int total;
		private String rew_opt;
		

		public String getRew_opt() {
			return rew_opt;
		}
		public void setRew_opt(String rew_opt) {
			this.rew_opt = rew_opt;
		}
		public int getOrderno() {
			return orderno;
		}
		public void setOrderno(int orderno) {
			this.orderno = orderno;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getCardnum() {
			return cardnum;
		}
		public void setCardnum(String cardnum) {
			this.cardnum = cardnum;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		public int getPro_No() {
			return pro_No;
		}
		public void setPro_No(int pro_No) {
			this.pro_No = pro_No;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getPostnum() {
			return postnum;
		}
		public void setPostnum(int postnum) {
			this.postnum = postnum;
		}
		public String getAddress1() {
			return address1;
		}
		public void setAddress1(String address1) {
			this.address1 = address1;
		}
		public String getAddress2() {
			return address2;
		}
		public void setAddress2(String address2) {
			this.address2 = address2;
		}
		public int getTotal() {
			return total;
		}
		public void setTotal(int total) {
			this.total = total;
		}
		
		
		
}
