package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class PaymentMgr {

	private DBConnectionMgr pool = null;
	public PaymentMgr(){
		pool = DBConnectionMgr.getInstance();
	}
	//������Ʈ �̸� �������� 
	public String getName(int prono) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String name = null;
		try {
			con = pool.getConnection();
			sql = "select Pro_name from project where Pro_No = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, prono);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				name = rs.getString("Pro_name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return name;
	}
	
	
	//������ ���� �������� (���̸�Ʈ ������ 1_������ ����)
	public Vector<RewardBean> getRewardList(int prono){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<RewardBean> vlist = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "select * from rewardtest where Pro_No = ? ORDER BY rew_price";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, prono);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RewardBean bean = new RewardBean();
				bean.setPro_No(rs.getInt("Pro_No"));
				bean.setRew_no(rs.getInt("rew_no"));
				bean.setRew_name(rs.getString("rew_name"));
				bean.setRew_info(rs.getString("rew_info"));
				bean.setRew_price(rs.getInt("rew_price"));
				bean.setRew_opt(rs.getString("rew_opt"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	
	
	//������ȣ �˻�
		public Vector<PostNumBean> zipcodeRead(String street) {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<PostNumBean> vlist = new Vector<PostNumBean>();
			try {
				con = pool.getConnection();
				sql = "SELECT * FROM address WHERE street LIKE ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%"+street+"%");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					PostNumBean bean = new PostNumBean(); 
					bean.setPostnum(rs.getString(1));
					bean.setCity(rs.getString(2)); 
					bean.setGu(rs.getString(3)); 
					bean.setStreet(rs.getString(4)); 
					bean.setStreetNum(rs.getString(5));
					vlist.addElement(bean); 
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		
	//������ ����� (�Է¹޾Ƽ� DB �����ϱ�)
	public void insertShipment(Promemberbean pmbean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "INSERT INTO shipment (email, cardnum, phone, Pro_No, name, postnum, address1, address2, total, rew_opt)"
					+ "VALUES (?, ?, ?, ?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, pmbean.getEmail());
			pstmt.setString(2, pmbean.getCardnum());
			pstmt.setString(3, pmbean.getPhone());
			pstmt.setInt(4, pmbean.getPro_No());
			pstmt.setString(5, pmbean.getName());
			pstmt.setInt(6, pmbean.getPostnum()); 
			pstmt.setString(7, pmbean.getAddress1());
			pstmt.setString(8, pmbean.getAddress2());
			pstmt.setInt(9, pmbean.getTotal());
			pstmt.setString(10, pmbean.getRew_opt());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	
	
	//������ ������ �Ŀ��ݰ� �Ŀ��ڼ� ������Ʈ
	public void updateProcash(ProInsBean prbean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			con = pool.getConnection();
			sql = "update project set Pro_cash = Pro_cash + ?, Pro_patron = Pro_patron + 1  where Pro_No =?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, prbean.getPro_cash());
			pstmt.setInt(2, prbean.getPro_No());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return;
	}
	
}
