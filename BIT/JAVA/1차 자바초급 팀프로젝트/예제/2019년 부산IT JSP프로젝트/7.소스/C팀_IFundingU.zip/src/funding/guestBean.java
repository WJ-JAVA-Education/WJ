package funding;

public class guestBean {

	private int num;
	private String email;
	private String contents;
	private String  ndate;
	private int Pro_No;
	
	public int getPro_No() {
		return Pro_No;
	}
	public void setPro_No(int pro_No) {
		Pro_No = pro_No;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getNdate() {
		return ndate;
	}
	public void setNdate(String ndate) {
		this.ndate = ndate;
	}
}
