package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class RewardMgr {

	private DBConnectionMgr pool;
	
	public RewardMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	public Vector<RewardBean> getReward(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<RewardBean> vlist = new Vector<RewardBean>();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RewardBean bean = new RewardBean();
				bean.setRew_no(rs.getInt("rew_no"));
				bean.setRew_name(rs.getString("rew_name"));
				bean.setRew_info(rs.getString("rew_info"));
				bean.setRew_price(rs.getInt("rew_price"));
				bean.setPro_No(rs.getInt("Pro_No"));
				bean.setRew_opt(rs.getString("rew_opt"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}
