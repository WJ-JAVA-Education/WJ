package funding;

public class RewardPriceBean {
	private int rew_no;
	private String rew_name;
	private String rew_info;
	private String rew_opt;
	private int Pro_No;
	private int rew_price;
	
	
	public int getRew_no() {
		return rew_no;
	}
	public void setRew_no(int rew_no) {
		this.rew_no = rew_no;
	}
	public String getRew_name() {
		return rew_name;
	}
	public void setRew_name(String rew_name) {
		this.rew_name = rew_name;
	}
	public String getRew_info() {
		return rew_info;
	}
	public void setRew_info(String rew_info) {
		this.rew_info = rew_info;
	}
	public String getRew_opt() {
		return rew_opt;
	}
	public void setRew_opt(String rew_opt) {
		this.rew_opt = rew_opt;
	}
	public int getPro_No() {
		return Pro_No;
	}
	public void setPro_No(int pro_No) {
		Pro_No = pro_No;
	}
	public int getRew_price() {
		return rew_price;
	}
	public void setRew_price(int rew_price) {
		this.rew_price = rew_price;
	}
	
	
}
