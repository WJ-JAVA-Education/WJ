package funding;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.filters.AddDefaultCharsetFilter;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import funding.UtilMgr;

public class ProjMgr {
	
	private DBConnectionMgr pool;
	private static final String UPLOAD = "C:/Users/it/Desktop/IFundingU/WebContent/img/";
	/*private static final String UPLOAD = "C:/Jsp/eclipse-workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/IFundingU/HomePage/img";*/
	private static final String ENCTYPE = "EUC-KR";
	private static final int MAXSIZE = 10*1024*1024;
	
	
	public ProjMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	

	
	// ���� �ֽ� ������Ʈ��ȣ
	public int maxNum() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int i = 0;
		try {
			con = pool.getConnection();
			sql = "select max(Pro_No) from project";
			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return i;
	}
	
	
	// ������Ʈ �����
	public ProInsBean getProject(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		ProInsBean piBean = new ProInsBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM project WHERE Pro_No = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				piBean.setPro_No(rs.getInt("Pro_No"));
				piBean.setPro_acnt(rs.getString("pro_acnt"));
				piBean.setPro_Adrs(rs.getString("Pro_Adrs"));
				piBean.setPro_bank(rs.getInt("Pro_bank"));
				piBean.setPro_cash(rs.getInt("rew_name"));
				piBean.setPro_cat(rs.getInt("Pro_cat"));
				piBean.setPro_findate(rs.getString("Pro_findate"));
				piBean.setPro_goal(rs.getInt("Pro_goal"));
				piBean.setPro_name(rs.getString("Pro_name"));
				piBean.setPro_refund(rs.getString("pro_refund"));
				piBean.setPro_story(rs.getString("pro_story"));
				piBean.setPro_img(rs.getString("Pro_img"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return piBean;
	}
	
	
	public void insPro(ProInsBean pBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "insert project(Pro_name) values(null)";
			pstmt = con.prepareStatement(sql);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	
	public boolean insPage1(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			HttpSession session = req.getSession();
			MultipartRequest multi = 
					new MultipartRequest(req, UPLOAD, MAXSIZE, ENCTYPE, new DefaultFileRenamePolicy());
			session.setAttribute("Pro_No", Integer.parseInt(multi.getParameter("Pro_No")));
			session.setAttribute("Pro_name", multi.getParameter("Pro_name"));
			session.setAttribute("Pro_cat", Integer.parseInt(multi.getParameter("Pro_cat")));
			session.setAttribute("Pro_Adrs", multi.getParameter("Pro_Adrs"));
			session.setAttribute("Pro_img", multi.getParameter("Pro_img"));
			
			con = pool.getConnection();
			if (multi.getFilesystemName("Pro_img") == null) { //������ ���� ����.
				sql = "UPDATE project SET Pro_name = ?, Pro_cat = ?, Pro_Adrs = ?, email=? WHERE Pro_No = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, multi.getParameter("Pro_name"));
				pstmt.setInt(2, Integer.parseInt(multi.getParameter("Pro_cat")));
				pstmt.setString(3, multi.getParameter("Pro_Adrs"));
				pstmt.setString(4, multi.getParameter("email"));
				pstmt.setInt(5, Integer.parseInt(multi.getParameter("Pro_No")));
				
			}else { //���ϱ��� ������.
				sql = "UPDATE project SET Pro_name = ?, Pro_cat = ?, Pro_Adrs = ?, Pro_img = ?, email=? WHERE Pro_No = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, multi.getParameter("Pro_name"));
				pstmt.setInt(2, Integer.parseInt(multi.getParameter("Pro_cat")));
				pstmt.setString(3, multi.getParameter("Pro_Adrs"));
				pstmt.setString(4, multi.getFilesystemName("Pro_img"));
				pstmt.setString(5, multi.getParameter("email"));
				pstmt.setInt(6, Integer.parseInt(multi.getParameter("Pro_No")));
			}
			if (pstmt.executeUpdate() == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	public void insPage2(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			HttpSession session = req.getSession();
			MultipartRequest multi = 
					new MultipartRequest(req, UPLOAD, MAXSIZE, ENCTYPE, new DefaultFileRenamePolicy());
			session.setAttribute("Pro_goal", Integer.parseInt(multi.getParameter("Pro_goal")));
			session.setAttribute("Pro_findate", multi.getParameter("Pro_findate"));
			session.setAttribute("Pro_bank", Integer.parseInt(multi.getParameter("Pro_bank")));
			session.setAttribute("Pro_acnt", multi.getParameter("Pro_acnt"));
			session.setAttribute("Pro_refund", multi.getParameter("Pro_refund"));
			con = pool.getConnection();
			sql = "update project set Pro_goal=?, Pro_findate=?, Pro_bank=?, Pro_acnt=?, Pro_refund = ? where Pro_No=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(multi.getParameter("Pro_goal")));
			pstmt.setString(2, multi.getParameter("Pro_findate"));
			pstmt.setInt(3, Integer.parseInt(multi.getParameter("Pro_bank")));
			pstmt.setString(4, multi.getParameter("Pro_acnt"));
			pstmt.setString(5, multi.getParameter("Pro_refund"));
			pstmt.setInt(6, Integer.parseInt(multi.getParameter("Pro_No")));

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return;
	}
	
	public void insPage3(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			HttpSession session = req.getSession();
			MultipartRequest multi = 
					new MultipartRequest(req, UPLOAD, MAXSIZE, ENCTYPE, new DefaultFileRenamePolicy());
			session.setAttribute("Pro_story", multi.getParameter("Pro_story"));
			con = pool.getConnection();
			sql = "update project set Pro_story=?, Pro_cash = ?, Pro_patron = ?, Pro_check = ? where Pro_No=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, multi.getParameter("Pro_story"));
			pstmt.setInt(2, 0);
			pstmt.setInt(3, 0);
			pstmt.setInt(4, 0);
			pstmt.setInt(5, Integer.parseInt(multi.getParameter("Pro_No")));
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return;
	}
	
	// ���� �Է�
	public void insRew_price(int Pro_No, int rew_price) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();			
			sql = "insert rewardtest(Pro_No, rew_price) values(?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			pstmt.setInt(2, rew_price);

			pstmt.executeUpdate();
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return;
	}
	
	// ���� ����
	public void delRew_num(int rew_no, int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "delete from rewardtest where rew_no = ? and Pro_No = ?";
			pstmt =  con.prepareStatement(sql);
			pstmt.setInt(1, rew_no);
			pstmt.setInt(2, Pro_No);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	

	
	public boolean upRew_num(int rew_price, int rew_no, int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
		
			con = pool.getConnection();
			sql = "update rewardtest set rew_price=?  where rew_no=? and Pro_No = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, rew_price);
			pstmt.setInt(2, rew_no);
			pstmt.setInt(3, Pro_No);
			
			if(pstmt.executeUpdate() == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	
	public RewardPriceBean getNum(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		RewardPriceBean rpBean = new RewardPriceBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No = ? ORDER BY rew_no DESC LIMIT 0,1";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_num"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info("rew_info");
				rpBean.setRew_name("rew_name");
				rpBean.setRew_opt("rew_opt");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rpBean;
	}
	
	public RewardPriceBean getPrice1(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		RewardPriceBean rpBean = new RewardPriceBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No = ? ORDER BY rew_no asc LIMIT 0,1";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_no"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info("rew_info");
				rpBean.setRew_name("rew_name");
				rpBean.setRew_opt("rew_opt");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rpBean;
	}
	
	public RewardPriceBean getNum2(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		RewardPriceBean rpBean = new RewardPriceBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No = ? ORDER BY rew_no DESC LIMIT 1,2";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_no"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info("rew_info");
				rpBean.setRew_name("rew_name");
				rpBean.setRew_opt("rew_opt");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rpBean;
	}
	
	public RewardPriceBean getPrice2(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		RewardPriceBean rpBean = new RewardPriceBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No = ? ORDER BY rew_no asc LIMIT 1,1";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_no"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info("rew_info");
				rpBean.setRew_name("rew_name");
				rpBean.setRew_opt("rew_opt");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rpBean;
	}
	
	public RewardPriceBean getPrice3(int Pro_No) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		RewardPriceBean rpBean = new RewardPriceBean();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM rewardtest WHERE Pro_No = ? ORDER BY rew_no asc LIMIT 2,1";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_no"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info("rew_info");
				rpBean.setRew_name("rew_name");
				rpBean.setRew_opt("rew_opt");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rpBean;
	}
	
	public void upReward(String rew_name, String rew_info, String rew_opt, int Pro_No, int rew_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "update rewardtest set rew_name=?, rew_info=?, rew_opt=? where Pro_No=? and rew_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, rew_name);
			pstmt.setString(2, rew_info);
			pstmt.setString(3, rew_opt);
			pstmt.setInt(4, Pro_No);
			pstmt.setInt(5, rew_no);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return;
	}
	
	public Vector<RewardPriceBean> getList(int Pro_No, int rew_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<RewardPriceBean> rplist = new Vector<RewardPriceBean>();
		try {
			con = pool.getConnection();
			sql = "select * from rewardtest where Pro_No = ? and rew_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			pstmt.setInt(2, rew_no);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RewardPriceBean rpBean = new RewardPriceBean();
				rpBean.setPro_No(rs.getInt("Pro_No"));
				rpBean.setRew_no(rs.getInt("rew_no"));
				rpBean.setRew_price(rs.getInt("rew_price"));
				rpBean.setRew_info(rs.getString("rew_info"));
				rpBean.setRew_name(rs.getString("rew_name"));
				rpBean.setRew_opt(rs.getString("rew_opt"));
				rplist.addElement(rpBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return rplist;
	} 
}