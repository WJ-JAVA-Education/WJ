package funding;

public class productBean {
	private int num;
	private int proprice;
	private String proname;
	private String proimage;
	private String prodate;
	private int patron;
	private int goalprice;
	private String findate;
		
	public String getFindate() {
		return findate;
	}
	public void setFindate(String findate) {
		this.findate = findate;
	}
	public int getGoalprice() {
		return goalprice;
	}
	public void setGoalprice(int goalprice) {
		this.goalprice = goalprice;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getProprice() {
		return proprice;
	}
	public void setProprice(int proprice) {
		this.proprice = proprice;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public String getProimage() {
		return proimage;
	}
	public void setProimage(String proimage) {
		this.proimage = proimage;
	}
	public String getProdate() {
		return prodate;
	}
	public void setProdate(String prodate) {
		this.prodate = prodate;
	}
	public int getPatron() {
		return patron;
	}
	public void setPatron(int patron) {
		this.patron = patron;
	}
	
	
}
