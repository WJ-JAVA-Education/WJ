package funding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import funding.CommentBean;
import funding.guestBean;
import funding.DBConnectionMgr;


public class guestMgr {

	private DBConnectionMgr pool;
	private final SimpleDateFormat SDF_DATE =
			new SimpleDateFormat("yyyy'��'  M'��' d'��' (E)");
	private final SimpleDateFormat SDF_TIME =
			new SimpleDateFormat("H:mm:ss");

	public guestMgr() {
		pool = DBConnectionMgr.getInstance();
	}

	//GuestBook Insert
	public void insertGuestBook(guestBean bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		System.out.println(bean.getContents());
		try {
			con = pool.getConnection();
			sql = "INSERT guesttest(email, contents, ndate, Pro_No) VALUES (?, ?, now(), ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getEmail());
			pstmt.setString(2, bean.getContents());
			pstmt.setInt(3, bean.getPro_No());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}

	//GuestBook List : ��б��� ���� �� �����ڸ� �� �� ����.
	public Vector<guestBean> listGuestBook(int  Pro_No){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<guestBean> vlist = new Vector<guestBean>();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM guesttest "
					+ "WHERE Pro_No = ? ORDER BY num DESC";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Pro_No);
			rs = pstmt.executeQuery();

			while(rs.next()) {
				guestBean bean = new guestBean();
				bean.setNum(rs.getInt("num")); //num
				bean.setEmail(rs.getString("email")); //email
				bean.setContents(rs.getString("contents")); //contents
				String tempDate = SDF_DATE.format(rs.getDate("ndate")); //��¥
				bean.setNdate(tempDate);
				bean.setPro_No(rs.getInt("Pro_No")); //������Ʈ �ѹ�
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//Comment List
	public Vector<CommentBean> listComment(int num){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<CommentBean> vlist = new Vector<CommentBean>();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM comment WHERE num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				CommentBean bean = new CommentBean();
				bean.setCnum(rs.getInt("cnum"));
				bean.setNum(rs.getInt("num"));
				bean.setCemail(rs.getString("cemail"));
				bean.setComment(rs.getString("comment"));
				String tempDate = SDF_DATE.format(rs.getDate("cdate"));
				bean.setCdate(tempDate);
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//Comment Insert
	public void insertComment(CommentBean bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "INSERT INTO comment (num, cemail, comment, cdate)"
					+ "VALUES (?, ?, ?, now())";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bean.getNum());
			pstmt.setString(2, bean.getCemail());
			pstmt.setString(3, bean.getComment());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
}
