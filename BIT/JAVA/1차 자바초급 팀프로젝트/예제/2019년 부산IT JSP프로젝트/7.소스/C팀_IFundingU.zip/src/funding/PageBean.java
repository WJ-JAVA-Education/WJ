package funding;

public class PageBean {
	private int Proj_No;
	private String Proj_name;
	private int Proj_cat;
	private String Proj_img;
	private String Proj_Adrs;
	private int Proj_goal;
	private String Proj_findate;
	private String Proj_acnt;
	private int Proj_bank;
	private String Proj_refund;
	private String Proj_story;
	private int Proj_memno;
	private int Proj_check;
	private int Proj_cash;
	
	public int getProj_No() {
		return Proj_No;
	}
	public void setProj_No(int proj_No) {
		Proj_No = proj_No;
	}
	public String getProj_name() {
		return Proj_name;
	}
	public void setProj_name(String proj_name) {
		Proj_name = proj_name;
	}
	public int getProj_cat() {
		return Proj_cat;
	}
	public void setProj_cat(int proj_cat) {
		Proj_cat = proj_cat;
	}
	public String getProj_img() {
		return Proj_img;
	}
	public void setProj_img(String proj_img) {
		Proj_img = proj_img;
	}
	public String getProj_Adrs() {
		return Proj_Adrs;
	}
	public void setProj_Adrs(String proj_Adrs) {
		Proj_Adrs = proj_Adrs;
	}
	public int getProj_goal() {
		return Proj_goal;
	}
	public void setProj_goal(int proj_goal) {
		Proj_goal = proj_goal;
	}
	public String getProj_findate() {
		return Proj_findate;
	}
	public void setProj_findate(String proj_findate) {
		Proj_findate = proj_findate;
	}
	public String getProj_acnt() {
		return Proj_acnt;
	}
	public void setProj_acnt(String proj_acnt) {
		Proj_acnt = proj_acnt;
	}
	public int getProj_bank() {
		return Proj_bank;
	}
	public void setProj_bank(int proj_bank) {
		Proj_bank = proj_bank;
	}
	public String getProj_refund() {
		return Proj_refund;
	}
	public void setProj_refund(String proj_refund) {
		Proj_refund = proj_refund;
	}
	public String getProj_story() {
		return Proj_story;
	}
	public void setProj_story(String proj_story) {
		Proj_story = proj_story;
	}
	public int getProj_memno() {
		return Proj_memno;
	}
	public void setProj_memno(int proj_memno) {
		Proj_memno = proj_memno;
	}
	public int getProj_check() {
		return Proj_check;
	}
	public void setProj_check(int proj_check) {
		Proj_check = proj_check;
	}
	public int getProj_cash() {
		return Proj_cash;
	}
	public void setProj_cash(int proj_cash) {
		Proj_cash = proj_cash;
	}
	
}
