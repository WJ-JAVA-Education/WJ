package menu;

public class ordersBean {

	private String oNum = null; // �ֹ���ȣ
	private String id =  null; // ���̵�
	private String cNick = null; //�г���
	private String cAddress = null; // �ּ�
	private String rName = null; // �Ĵ��̸�
	private String cPhone = null; // ����� ����ȣ
	private String menu = ""; // �޴� �̸�
	private int count = 0;
	private String oDate = null; // �ֹ� �ð�
	private String oRequest = null; //��û����
	private String orderType = null; // ���, �����̳�
	private String payType = null;	 // ���� Ÿ��
	private String orderStatus;
	private int mPrice;
	private int totalPrice;	//�հ�
	private String mImg;
	private String[] oSatus; //��޻���
	private String oYear;	//odate���� �⵵ ��������
	
		
	public String[] getoSatus() {
		return oSatus;
	}
	public void setoSatus(String[] oSatus) {
		this.oSatus = oSatus;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getoNum() {
		return oNum;
	}
	public void setoNum(String oNum) {
		this.oNum = oNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getcNick() {
		return cNick;
	}
	public void setcNick(String cNick) {
		this.cNick = cNick;
	}
	public String getcAddress() {
		return cAddress;
	}
	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}
	public String getrName() {
		return rName;
	}
	public void setrName(String rName) {
		this.rName = rName;
	}
	public String getcPhone() {
		return cPhone;
	}
	public void setcPhone(String cPhone) {
		this.cPhone = cPhone;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getoDate() {
		return oDate;
	}
	public void setoDate(String oDate) {
		this.oDate = oDate;
	}
	public String getoRequest() {
		return oRequest;
	}
	public void setoRequest(String oRequest) {
		this.oRequest = oRequest;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public int getmPrice() {
		return mPrice;
	}
	public void setmPrice(int mPrice) {
		this.mPrice = mPrice;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getmImg() {
		return mImg;
	}
	public void setmImg(String mImg) {
		this.mImg = mImg;
	}
	public String getoYear() {
		return oYear;
	}
	public void setoYear(String oYear) {
		this.oYear = oYear;
	}
	
	
}
