package menu;

public class menuBean {
	
	private int idx; //�ε��� ��ȣ  
	private String rName; // �Ĵ��̸� 
	private String category; 
	private String menu; // �޴��̸� 
	private int mPrice; // �޴����� 1
	private String mInfo; // �޴� ���� 
	private String mImg; // �޴� �̹��� 
	private String mImgsize; // �޴� ���� ũ�� 
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getrName() {
		return rName;
	}
	public void setrName(String rName) {
		this.rName = rName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public int getmPrice() {
		return mPrice;
	}
	public void setmPrice(int mPrice) {
		this.mPrice = mPrice;
	}
	public String getmInfo() {
		return mInfo;
	}
	public void setmInfo(String mInfo) {
		this.mInfo = mInfo;
	}
	public String getmImg() {
		return mImg;
	}
	public void setmImg(String mImg) {
		this.mImg = mImg;
	}
	public String getmImgsize() {
		return mImgsize;
	}
	public void setmImgsize(String mImgsize) {
		this.mImgsize = mImgsize;
	}
		
}