package shoplogin;

public class loginBean {
	
	private String businessid;
	private String pwd;
	private String bsnsSector;
	private String bsnsCond;
	private String bsnsNm;
	private String addrRoad;
	private String addrRoad1;
	private String menu;
	private String tel;
	private String gugun;
	private float lat;
	private float lng;
	private String restImg;
	private int restImgsize;
	
	public String getBusinessid() {
		return businessid;
	}
	public void setBusinessid(String businessid) {
		this.businessid = businessid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getBsnsSector() {
		return bsnsSector;
	}
	public void setBsnsSector(String bsnsSector) {
		this.bsnsSector = bsnsSector;
	}
	public String getBsnsCond() {
		return bsnsCond;
	}
	public void setBsnsCond(String bsnsCond) {
		this.bsnsCond = bsnsCond;
	}
	public String getBsnsNm() {
		return bsnsNm;
	}
	public void setBsnsNm(String bsnsNm) {
		this.bsnsNm = bsnsNm;
	}
	public String getAddrRoad() {
		return addrRoad;
	}
	public void setAddrRoad(String addrRoad) {
		this.addrRoad = addrRoad;
	}
	public String getAddrRoad1() {
		return addrRoad1;
	}
	public void setAddrRoad1(String addrRoad1) {
		this.addrRoad1 = addrRoad1;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getGugun() {
		return gugun;
	}
	public void setGugun(String gugun) {
		this.gugun = gugun;
	}
	public float getLat() {
		return lat;
	}
	public void setLat(float lat) {
		this.lat = lat;
	}
	public float getLng() {
		return lng;
	}
	public void setLng(float lng) {
		this.lng = lng;
	}
	public String getRestImg() {
		return restImg;
	}
	public void setRestImg(String restImg) {
		this.restImg = restImg;
	}
	public int getRestImgsize() {
		return restImgsize;
	}
	public void setRestImgsize(int restImgsize) {
		this.restImgsize = restImgsize;
	}
	
		
}