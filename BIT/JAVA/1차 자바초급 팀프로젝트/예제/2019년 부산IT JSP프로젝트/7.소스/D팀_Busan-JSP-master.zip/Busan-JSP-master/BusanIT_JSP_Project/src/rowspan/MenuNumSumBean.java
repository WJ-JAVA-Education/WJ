package rowspan;

public class MenuNumSumBean {

	private int num;
	private int menuNumSum;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getMenuNumSum() {
		return menuNumSum;
	}
	public void setMenuNumSum(int menuNumSum) {
		this.menuNumSum = menuNumSum;
	}
}
