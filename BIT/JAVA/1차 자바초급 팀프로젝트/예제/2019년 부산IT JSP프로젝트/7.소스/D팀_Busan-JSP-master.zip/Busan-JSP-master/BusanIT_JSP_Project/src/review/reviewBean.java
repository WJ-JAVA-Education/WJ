package review;

public class reviewBean {
	
		private int rNum;
		private String rNick;
		private String rId;
		private String rContent;
		private String rRegdate;
		private int rStar;
		private String oDate;
		private String ShopName;
		private String oNum;
		
		
		
		public String getrNick() {
			return rNick;
		}
		public void setrNick(String rNick) {
			this.rNick = rNick;
		}
		public int getrNum() {
			return rNum;
		}
		public void setrNum(int rNum) {
			this.rNum = rNum;
		}
		public String getrId() {
			return rId;
		}
		public void setrId(String rId) {
			this.rId = rId;
		}
		public String getrContent() {
			return rContent;
		}
		public void setrContent(String rContent) {
			this.rContent = rContent;
		}
		public String getrRegdate() {
			return rRegdate;
		}
		public void setrRegdate(String rRegdate) {
			this.rRegdate = rRegdate;
		}
		public int getrStar() {
			return rStar;
		}
		public void setrStar(int rStar) {
			this.rStar = rStar;
		}
		public String getoDate() {
			return oDate;
		}
		public void setoDate(String oDate) {
			this.oDate = oDate;
		}
		public String getShopName() {
			return ShopName;
		}
		public void setShopName(String shopName) {
			ShopName = shopName;
		}
		public String getoNum() {
			return oNum;
		}
		public void setoNum(String oNum) {
			this.oNum = oNum;
		}
		
		
		
		
}


