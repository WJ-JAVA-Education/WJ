package MenuList;

public class menu_listBean {
	
	private int idx;
	private String bsnsSector; //bsnsSector
	private String StoreCond;
	private String Storename;
	private String Storeaddr1;
	private String Storeaddr2;
	private String Bestmenu;
	private String tel;
	private float lat; //����
	private float lng; //�浵
	private String restImg;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getBsnsSector() {
		return bsnsSector;
	}
	public void setBsnsSector(String bsnsSector) {
		this.bsnsSector = bsnsSector;
	}
	public String getStoreCond() {
		return StoreCond;
	}
	public void setStoreCond(String storeCond) {
		StoreCond = storeCond;
	}
	public String getStorename() {
		return Storename;
	}
	public void setStorename(String storename) {
		Storename = storename;
	}
	public String getStoreaddr1() {
		return Storeaddr1;
	}
	public void setStoreaddr1(String storeaddr1) {
		Storeaddr1 = storeaddr1;
	}
	public String getStoreaddr2() {
		return Storeaddr2;
	}
	public void setStoreaddr2(String storeaddr2) {
		Storeaddr2 = storeaddr2;
	}
	public String getBestmenu() {
		return Bestmenu;
	}
	public void setBestmenu(String bestmenu) {
		Bestmenu = bestmenu;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public float getLat() {
		return lat;
	}
	public void setLat(float lat) {
		this.lat = lat;
	}
	public float getLng() {
		return lng;
	}
	public void setLng(float lng) {
		this.lng = lng;
	}
	public String getRestImg() {
		return restImg;
	}
	public void setRestImg(String restImg) {
		this.restImg = restImg;
	}
	
}
