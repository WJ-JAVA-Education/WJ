package tour;

public class OrderBean {
	
	private int no;
	private int productNo;
	private int quantity1;
	private int quantity2;
	private int quantityTotal;
	private String date;
	private String tourdate;
	private String tourtime;
	private String senddate;
	private String id;
	private String name;
	private String state;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public int getQuantity1() {
		return quantity1;
	}
	public void setQuantity1(int quantity1) {
		this.quantity1 = quantity1;
	}
	public int getQuantity2() {
		return quantity2;
	}
	public void setQuantity2(int quantity2) {
		this.quantity2 = quantity2;
	}
	public int getQuantityTotal() {
		return quantityTotal;
	}
	public void setQuantityTotal(int quantityTotal) {
		this.quantityTotal = quantityTotal;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTourdate() {
		return tourdate;
	}
	public void setTourdate(String tourdate) {
		this.tourdate = tourdate;
	}
	public String getTourtime() {
		return tourtime;
	}
	public void setTourtime(String tourtime) {
		this.tourtime = tourtime;
	}
	public String getSenddate() {
		return senddate;
	}
	public void setSenddate(String senddate) {
		this.senddate = senddate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
