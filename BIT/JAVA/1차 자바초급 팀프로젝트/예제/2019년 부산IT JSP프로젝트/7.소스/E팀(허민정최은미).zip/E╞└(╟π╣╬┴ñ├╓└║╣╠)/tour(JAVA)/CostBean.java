package tour;

public class CostBean {
	
	private int num;
	private String name;
	private String childbirth;
	private String[] saleitem1;
	private String[] saleitem2;
	private String[] saleitem3;
	private String[] saleitem4;
	private String email;
	private String hp;
	private int adultNum;
	private int childNum;
	private String tourDay;
	private String tourTime;
	private String regdate;
	private String senddate;
	private String comment;
	private String saleitem11;
	private String saleitem22;
	private String saleitem33;
	private String saleitem44;
	private String state;
	private String fcost;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChildbirth() {
		return childbirth;
	}
	public void setChildbirth(String childbirth) {
		this.childbirth = childbirth;
	}
	public String[] getSaleitem1() {
		return saleitem1;
	}
	public void setSaleitem1(String[] saleitem1) {
		this.saleitem1 = saleitem1;
	}
	public String[] getSaleitem2() {
		return saleitem2;
	}
	public void setSaleitem2(String[] saleitem2) {
		this.saleitem2 = saleitem2;
	}
	public String[] getSaleitem3() {
		return saleitem3;
	}
	public void setSaleitem3(String[] saleitem3) {
		this.saleitem3 = saleitem3;
	}
	public String[] getSaleitem4() {
		return saleitem4;
	}
	public void setSaleitem4(String[] saleitem4) {
		this.saleitem4 = saleitem4;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public int getAdultNum() {
		return adultNum;
	}
	public void setAdultNum(int adultNum) {
		this.adultNum = adultNum;
	}
	public int getChildNum() {
		return childNum;
	}
	public void setChildNum(int childNum) {
		this.childNum = childNum;
	}
	public String getTourDay() {
		return tourDay;
	}
	public void setTourDay(String tourDay) {
		this.tourDay = tourDay;
	}
	public String getTourTime() {
		return tourTime;
	}
	public void setTourTime(String tourTime) {
		this.tourTime = tourTime;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getSenddate() {
		return senddate;
	}
	public void setSenddate(String senddate) {
		this.senddate = senddate;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getSaleitem11() {
		return saleitem11;
	}
	public void setSaleitem11(String saleitem11) {
		this.saleitem11 = saleitem11;
	}
	public String getSaleitem22() {
		return saleitem22;
	}
	public void setSaleitem22(String saleitem22) {
		this.saleitem22 = saleitem22;
	}
	public String getSaleitem33() {
		return saleitem33;
	}
	public void setSaleitem33(String saleitem33) {
		this.saleitem33 = saleitem33;
	}
	public String getSaleitem44() {
		return saleitem44;
	}
	public void setSaleitem44(String saleitem44) {
		this.saleitem44 = saleitem44;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getFcost() {
		return fcost;
	}
	public void setFcost(String fcost) {
		this.fcost = fcost;
	}
	
	
	
}
