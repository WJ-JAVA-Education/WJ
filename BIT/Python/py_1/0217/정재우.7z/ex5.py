page1 = 3
page120 = (page1*120)//60
print(page120)
