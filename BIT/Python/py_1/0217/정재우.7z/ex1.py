num1 = 47
num2 = 18

더하기 = num1+num2
빼기 = num1-num2
곱하기 = num1*num2
나누기 = num1//num2

print(더하기, 빼기, 곱하기, 나누기)
