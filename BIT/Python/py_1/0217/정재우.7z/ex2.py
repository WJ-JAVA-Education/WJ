
m3 = 2100
m1 = m3//3

m45 = m1*45


print(m45)
