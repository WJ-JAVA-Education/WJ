money = 3000000
bonus = 300000
total = (money+bonus)-(money+bonus)*0.20
print(total)
