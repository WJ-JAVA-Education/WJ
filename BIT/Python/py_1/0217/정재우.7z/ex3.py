TV_c = 3500000
count = TV_c-(TV_c*0.25)
print(count)
