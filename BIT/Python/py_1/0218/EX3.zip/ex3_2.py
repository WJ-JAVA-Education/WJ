import math

pi = math.pi

r = float(input("r 의 값 "))
h = float(input("h 의 값 "))
result = (r ** 2) * pi * h
A = round(result, 3)
print(A)
