num1 = input("정수를 입력하세요: ")
print(sum(map(int, num1)))