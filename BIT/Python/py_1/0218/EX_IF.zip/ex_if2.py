score = float(input(" 점수를 입력해 주세요 : "))
if score >= 4.2:
    print("당신의 평점은", score)
    print("해외 연수 기회 부여")
