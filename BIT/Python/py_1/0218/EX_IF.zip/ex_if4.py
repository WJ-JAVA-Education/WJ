age = int(input(" 나이를 입력 해주세요 : "))

if age >= 65:
    print(" 경로 우대 승차권 ")
else:
    print(" 일반 승차권 ")
print(" 감사합니다 ")
