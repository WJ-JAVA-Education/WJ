# ex8.py

import m_ex8

a = int(input("첫 번째 숫자 : "))
b = int(input("두 번째 숫자 : "))
c = int(input("세 번째 숫자 : "))

max = print("가장 큰 수:",m_ex8.findMax(a,b,c))
min = print("가장 작은 수:",m_ex8.findMin(a,b,c))
sum = print("숫자의 합:",m_ex8.findSum(a,b,c))

