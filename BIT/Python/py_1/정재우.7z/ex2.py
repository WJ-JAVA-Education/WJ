# ex2.py

num1 = int(input("input num: "))
num2 = int(input("input num2: "))

print(num1," + ",num2," = ",(num1+num2))
print(num1," - ",num2," = ",(num1-num2))
print(num1," * ",num2," = ",(num1*num2))
print(num1," / ",num2," = ",(num1/num2))

