# ex3.py

eng = input("영어 문장 입력 : ")

print("단어를 모두 대문자료 표시:",eng.upper())
print("입력된 단어의 길이:",len(eng))
print("단어에 t가 몇번 나오는가?",eng.count('t'))

