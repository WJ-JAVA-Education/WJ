# ex1.py

r = int(input("반지름 입력 : "))
print("원의 넓이 : ",(r*r*3.14))

